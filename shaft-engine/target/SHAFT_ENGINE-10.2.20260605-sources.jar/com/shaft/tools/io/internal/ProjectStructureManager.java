package com.shaft.tools.io.internal;

import com.shaft.cli.FileActions;
import com.shaft.properties.internal.Properties;
import com.shaft.tools.io.ReportManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.TestNG;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Initializes runtime project folders and service provider metadata files.
 */
public class ProjectStructureManager {
    private static final Logger logger = LogManager.getLogger(ProjectStructureManager.class);

    /**
     * Detects the active test runner from the current stack trace.
     *
     * @return the inferred execution mode
     */
    public static RunType identifyRunType() {
        Supplier<Stream<String>> stacktraceSupplier = () -> Arrays.stream(new Throwable().getStackTrace())
                .map(StackTraceElement::getClassName);
        var isUsingJunitDiscovery = stacktraceSupplier.get()
                .anyMatch(org.junit.platform.launcher.core.EngineDiscoveryOrchestrator.class.getCanonicalName()::equals);
        var isUsingTestNG = stacktraceSupplier.get().anyMatch(TestNG.class.getCanonicalName()::equals);
        var isUsingCucumber = stacktraceSupplier.get()
                .anyMatch(io.cucumber.core.runner.Runner.class.getCanonicalName()::equals);
        if (isUsingJunitDiscovery || isUsingTestNG) {
            logger.info("TestNG run detected...");
            return RunType.TESTNG;
        } else if (isUsingCucumber) {
            logger.info("Cucumber run detected...");
            return RunType.CUCUMBER;
        } else {
            logger.info("JUnit5 run detected...");
            return RunType.JUNIT;
        }
    }

    /**
     * Prepares project structure and listener registration files based on run type.
     *
     * @param runType current execution framework mode
     */
    public static void initialize(RunType runType) {
        ReportManager.logDiscrete("Initializing Project Structure...");
        if (Properties.platform.executionAddress().equals("local")
                && !Paths.get(System.getProperty("user.dir")).getFileName().toString().equals("SHAFT_Engine")) {
            FileActions.getInstance(true).createFolder(Properties.paths.properties());
            FileActions.getInstance(true).createFolder(Properties.paths.dynamicObjectRepository());
            FileActions.getInstance(true).createFolder(Properties.paths.testData());
        }
        // manually override listeners configuration
        if (Properties.platform.executionAddress().equals("local")) {
            FileActions.getInstance(true).deleteFolder(Properties.paths.services());
            switch (runType) {
                case JUNIT -> {
                    FileActions.getInstance(true).createFolder(Properties.paths.services());
                    FileActions.getInstance(true).writeToFile(Properties.paths.services(), "org.junit.platform.launcher.LauncherSessionListener", "com.shaft.listeners.JunitListener");
                }
                case TESTNG, AI_AGENT, CUCUMBER -> {
                    FileActions.getInstance(true).createFolder(Properties.paths.services());
                    FileActions.getInstance(true).writeToFile(Properties.paths.services(), "org.testng.ITestNGListener", "com.shaft.listeners.TestNGListener");
                    FileActions.getInstance(true).writeToFile(Properties.paths.services(), "org.testng.IAnnotationTransformer", "com.shaft.listeners.TestNGListener");
                }
//                case CUCUMBER -> {
//                    FileActions.getInstance(true).createFolder(Properties.paths.services());
//                    FileActions.getInstance(true).writeToFile(Properties.paths.services(), "io.cucumber.plugin.ConcurrentEventListener", "com.shaft.listeners.CucumberFeatureListener");
//                }
            }
            createAllureListenersMetaFiles();
        }
    }

    private static void createAllureListenersMetaFiles() {
        FileActions.getInstance(true).createFolder(com.shaft.properties.internal.Properties.paths.services());
        Arrays.asList("io.qameta.allure.listener.ContainerLifecycleListener", "io.qameta.allure.listener.FixtureLifecycleListener",
                "io.qameta.allure.listener.StepLifecycleListener", "io.qameta.allure.listener.TestLifecycleListener").forEach(fileName -> FileActions.getInstance(true).writeToFile(Properties.paths.services(), fileName, "com.shaft.listeners.AllureListener"));
    }

    /**
     * Supported runtime execution modes used for listener bootstrapping.
     */
    public enum RunType {TESTNG, JUNIT, CUCUMBER, AI_AGENT}
}
